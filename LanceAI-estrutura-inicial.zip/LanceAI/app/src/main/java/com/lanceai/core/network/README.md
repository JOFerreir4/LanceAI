# Network

Ponto de extensão para integrações futuras. Nenhum cliente HTTP é ativado nesta versão.
