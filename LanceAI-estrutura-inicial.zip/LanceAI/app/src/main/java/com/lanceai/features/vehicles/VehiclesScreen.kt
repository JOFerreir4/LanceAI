package com.lanceai.features.vehicles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lanceai.core.database.VehicleDao
import com.lanceai.core.database.VehicleEntity
import kotlinx.coroutines.launch

@Composable
fun VehiclesScreen(dao: VehicleDao, onBack: () -> Unit) {
    val vehicles by dao.observeAll().collectAsState(initial = emptyList())
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Button(onClick = onBack) { Text("Voltar") }
            Text("  Meus veículos")
        }
        OutlinedTextField(value = make, onValueChange = { make = it }, label = { Text("Marca") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Modelo") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                if (make.isNotBlank() && model.isNotBlank()) {
                    scope.launch {
                        dao.insert(VehicleEntity(make = make.trim(), model = model.trim()))
                        make = ""
                        model = ""
                    }
                }
            },
            enabled = make.isNotBlank() && model.isNotBlank()
        ) { Text("Salvar veículo") }

        Text("Cadastrados: ${vehicles.size}")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vehicles, key = { it.id }) { vehicle ->
                Text("• ${vehicle.make} ${vehicle.model}")
            }
        }
    }
}
