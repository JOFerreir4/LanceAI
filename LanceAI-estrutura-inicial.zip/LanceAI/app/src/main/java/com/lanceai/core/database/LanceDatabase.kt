package com.lanceai.core.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [VehicleEntity::class], version = 1, exportSchema = false)
abstract class LanceDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
}
