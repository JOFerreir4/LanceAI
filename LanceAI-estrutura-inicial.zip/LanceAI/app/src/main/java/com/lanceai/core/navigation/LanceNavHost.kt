package com.lanceai.core.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.lanceai.core.database.LanceDatabase
import com.lanceai.features.home.HomeScreen
import com.lanceai.features.vehicles.VehiclesScreen

object Routes {
    const val HOME = "home"
    const val VEHICLES = "vehicles"
}

@Composable
fun LanceNavHost(
    database: LanceDatabase,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(onVehiclesClick = { navController.navigate(Routes.VEHICLES) })
        }
        composable(Routes.VEHICLES) {
            VehiclesScreen(dao = database.vehicleDao(), onBack = { navController.popBackStack() })
        }
    }
}
