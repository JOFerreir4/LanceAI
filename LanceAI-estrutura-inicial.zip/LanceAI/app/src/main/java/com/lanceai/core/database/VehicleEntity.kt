package com.lanceai.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val make: String,
    val model: String,
    val year: Int? = null,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
