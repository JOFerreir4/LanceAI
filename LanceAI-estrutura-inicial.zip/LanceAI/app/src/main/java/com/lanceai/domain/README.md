# Domain

Regras de negócio puras (avaliação financeira, riscos e cálculo de lance máximo) devem ficar aqui,
sem dependência de Android, Room ou serviços externos.
