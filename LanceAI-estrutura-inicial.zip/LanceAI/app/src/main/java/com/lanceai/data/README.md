# Data

Repositórios e fontes de dados. Mantenha integrações remotas isoladas de persistência local.
Nenhuma API ou scraping está configurado nesta versão.
