package com.lanceai.core.ui.theme

import androidx.compose.ui.graphics.Color

val Midnight = Color(0xFF101820)
val DeepBlue = Color(0xFF172B3B)
val ElectricCyan = Color(0xFF16B9D4)
val SignalGreen = Color(0xFF35D49A)
val IceWhite = Color(0xFFF2F5F8)
val AlertAmber = Color(0xFFF2B84B)
