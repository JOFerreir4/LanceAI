package com.lanceai.features.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(onVehiclesClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("LanceAI", style = MaterialTheme.typography.headlineLarge)
        Text("Antes do lance, inteligência.", color = MaterialTheme.colorScheme.primary)
        Text("Sua análise começa aqui. Cadastre veículos e, nas próximas etapas, avalie custos, riscos e lance máximo.")
        Button(onClick = onVehiclesClick) { Text("Meus veículos") }
        Text("Versão inicial 0.1.0", style = MaterialTheme.typography.labelMedium)
    }
}
