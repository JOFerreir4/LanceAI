package com.lanceai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.room.Room
import com.lanceai.core.database.LanceDatabase
import com.lanceai.core.navigation.LanceNavHost
import com.lanceai.core.ui.theme.LanceAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = Room.databaseBuilder(
            applicationContext,
            LanceDatabase::class.java,
            "lanceai.db"
        ).build()

        setContent {
            LanceAITheme {
                Surface {
                    LanceNavHost(database = remember { database })
                }
            }
        }
    }
}
