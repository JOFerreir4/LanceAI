# Compilar o LanceAI usando somente o celular

Este projeto inclui o workflow `.github/workflows/android-apk.yml` para compilar o APK nos servidores do GitHub Actions. Não é necessário Android Studio no celular.

## Passos

1. Crie uma conta gratuita em https://github.com/ (se ainda não tiver).
2. No navegador do celular, crie um repositório novo chamado `LanceAI`.
3. Envie os arquivos e pastas do projeto para a branch `main`, preservando a pasta `.github/workflows`.
4. Abra a aba **Actions** do repositório.
5. Se solicitado, habilite GitHub Actions para o repositório.
6. Selecione **Build LanceAI APK** e toque em **Run workflow** (ou aguarde a execução automática após enviar arquivos para `main`).
7. Aguarde o job terminar. Se ficar verde, abra a execução e baixe o artefato **LanceAI-debug-apk**.
8. Extraia o ZIP do artefato e instale `app-debug.apk` no Android. Talvez seja necessário permitir instalação pelo navegador/gerenciador de arquivos.

## Observações

- O GitHub Actions oferece uma franquia gratuita para repositórios públicos e limites para repositórios privados; confira a franquia vigente da sua conta antes de uso intensivo.
- O APK gerado é de depuração, não é assinado para distribuição pública.
- Não inclua senhas, chaves ou credenciais no repositório.
- Se o workflow falhar, abra os logs da etapa vermelha e compartilhe o texto do erro para correção.
