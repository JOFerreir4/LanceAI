# LanceAI — estrutura inicial

Aplicativo Android nativo para apoiar a análise de veículos de leilão. Esta base é local-first:
não exige servidor, conta, credenciais ou API paga.

**Slogan:** Antes do lance, inteligência.

## Requisitos

- Android Studio estável compatível com Android Gradle Plugin 8.13.x
- JDK 17
- Android SDK Platform 36
- Gradle Wrapper gerado/baixado pelo Android Studio na primeira abertura

## Abrir e compilar

1. Extraia o ZIP.
2. No Android Studio, escolha **Open** e selecione a pasta `LanceAI`.
3. Aguarde a sincronização do Gradle e a instalação dos componentes do SDK solicitados.
4. Selecione um emulador ou conecte o Android com Depuração USB ativada.
5. Use **Build > Make Project** para compilar.
6. Use **Run** para instalar e abrir no dispositivo.

Para gerar APK de depuração: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O APK normalmente será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## O que já está preparado

- Kotlin + Jetpack Compose + Material 3
- Navigation Compose com tela inicial e tela de veículos
- Room com tabela local mínima de veículos
- Coroutines/Flow para observar os registros
- Coil 3 e Kotlin Serialization incluídos como dependências para fases seguintes
- Identidade visual LanceAI
- Pacotes reservados para leilões, mercado, financeiro, visão, peças e relatórios

## Estrutura

```text
app/src/main/java/com/lanceai/
├── core/
│   ├── database/
│   ├── navigation/
│   ├── network/
│   └── ui/theme/
├── data/
├── domain/
└── features/
    ├── home/
    ├── auctions/
    ├── vehicles/
    ├── market/
    ├── finance/
    ├── vision/
    ├── parts/
    └── reports/
```

## Limites desta versão

- Não consulta Palácio dos Leilões, FIPE, Mercado Livre ou Shopee.
- Não realiza scraping nem presume API pública/autorizada.
- Não faz análise de imagens ou diagnóstico mecânico/jurídico.
- Não calcula lance máximo ainda.
- Não inclui Gradle Wrapper binário; o Android Studio pode configurar/baixar o wrapper durante a abertura.
- Versões de dependências são fixadas no catálogo `gradle/libs.versions.toml`; confirme compatibilidade e atualizações no Android Studio antes de uma build de produção.

## Próximos passos recomendados

1. Validar sincronização e build no Android Studio.
2. Criar modelos de lote, despesas, fotos e simulação.
3. Implementar motor financeiro puro com cenários e custos detalhados.
4. Adicionar importação manual de dados e fotos de lotes.
5. Só então avaliar integrações externas permitidas e análise visual.
