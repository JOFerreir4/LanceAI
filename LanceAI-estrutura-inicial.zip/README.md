# LanceAI

Aplicativo Android pessoal para apoiar a análise de veículos de leilão, inicialmente com foco no Palácio dos Leilões.

## Estado desta versão

Esta é uma base inicial enxuta: tela inicial, cadastro local de veículos e listagem persistida com Room. Não consulta o Palácio dos Leilões, FIPE, Mercado Livre ou Shopee ainda. Não faz scraping nem análise automática de fotos nesta etapa.

## Compilar pelo celular com GitHub Actions

1. Envie o conteúdo deste ZIP para a raiz do repositório `JOFerreir4/LanceAI`.
2. Mantenha o workflow em `.github/workflows/build-apk.yml`.
3. Abra a aba Actions e execute **Build LanceAI APK**.
4. Ao concluir, baixe o artefato `LanceAI-debug-apk` e extraia `app-debug.apk`.

## Requisitos técnicos

- JDK 17
- Gradle 8.13
- Android Gradle Plugin 8.13.0
- Kotlin 2.2.20
- Android SDK 36

## Próximos módulos

Pesquisa/cadastro de lotes, fotos, referências FIPE e mercado, cálculo de despesas/comissão/lance máximo, análise visual assistida e pesquisa de peças. Integrações externas ficam isoladas e dependem de fontes autorizadas e disponibilidade de APIs.
