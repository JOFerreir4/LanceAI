package com.lanceai.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private enum class EvaluationMode(val title: String) {
    RESALE("Revenda"), PERSONAL("Uso próprio"), COMPARE("Comparar")
}

private data class BidResult(val maxBid: Double, val totalCost: Double, val profitOrSaving: Double, val margin: Double)

private fun money(value: Double): String =
    NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(value)

private fun calculateBid(
    referenceValue: Double, commissionPct: Double, fixedCosts: Double,
    repairs: Double, contingencyPct: Double, targetPct: Double, resale: Boolean
): BidResult {
    val commission = (commissionPct.coerceAtLeast(0.0) / 100.0).coerceAtMost(0.99)
    val contingency = (contingencyPct.coerceAtLeast(0.0) / 100.0).coerceAtMost(1.0)
    val target = (targetPct.coerceAtLeast(0.0) / 100.0).coerceAtMost(0.99)
    val extras = fixedCosts.coerceAtLeast(0.0) + repairs.coerceAtLeast(0.0)
    val reserve = extras * contingency
    val desired = referenceValue.coerceAtLeast(0.0) * target
    val maxBid = ((referenceValue - extras - reserve - desired) / (1.0 + commission)).coerceAtLeast(0.0)
    val total = maxBid * (1.0 + commission) + extras + reserve
    val result = referenceValue - total
    return BidResult(maxBid, total, result, if (referenceValue > 0) result / referenceValue * 100 else 0.0)
}

@Composable
private fun MoneyField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { raw -> onValue(raw.filter { it.isDigit() || it == '.' || it == ',' }) },
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true
    )
}

@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    var mode by remember { mutableStateOf(EvaluationMode.RESALE) }
    var saleValue by remember { mutableStateOf("30000") }
    var marketValue by remember { mutableStateOf("30000") }
    var commission by remember { mutableStateOf("5") }
    var fixedCosts by remember { mutableStateOf("1500") }
    var repairs by remember { mutableStateOf("2000") }
    var contingency by remember { mutableStateOf("10") }
    var resaleMargin by remember { mutableStateOf("15") }
    var savingTarget by remember { mutableStateOf("10") }

    fun number(v: String) = v.replace(".", "").replace(",", ".").toDoubleOrNull() ?: 0.0
    val resale = calculateBid(number(saleValue), number(commission), number(fixedCosts), number(repairs), number(contingency), number(resaleMargin), true)
    val personal = calculateBid(number(marketValue), number(commission), number(fixedCosts), number(repairs), number(contingency), number(savingTarget), false)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Calculadora de lance", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Simulação offline • Palácio dos Leilões", color = MaterialTheme.colorScheme.secondary)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            EvaluationMode.values().forEachIndexed { index, item ->
                SegmentedButton(selected = mode == item, onClick = { mode = item }, shape = SegmentedButtonDefaults.itemShape(index, EvaluationMode.values().size)) { Text(item.title) }
            }
        }
        if (mode != EvaluationMode.PERSONAL) MoneyField("Valor estimado de venda (R$)", saleValue) { saleValue = it }
        if (mode != EvaluationMode.RESALE) MoneyField("Valor de mercado equivalente (R$)", marketValue) { marketValue = it }
        MoneyField("Comissão do leiloeiro (%)", commission) { commission = it }
        MoneyField("Despesas fixas (taxas, transporte, documentos) (R$)", fixedCosts) { fixedCosts = it }
        MoneyField("Reparos estimados (R$)", repairs) { repairs = it }
        MoneyField("Reserva para imprevistos (%) sobre despesas", contingency) { contingency = it }
        if (mode != EvaluationMode.PERSONAL) MoneyField("Margem de lucro desejada (%)", resaleMargin) { resaleMargin = it }
        if (mode != EvaluationMode.RESALE) MoneyField("Economia mínima desejada (%)", savingTarget) { savingTarget = it }
        if (mode != EvaluationMode.PERSONAL) ResultCard("Lance máximo para revenda", resale, number(saleValue))
        if (mode != EvaluationMode.RESALE) ResultCard("Lance máximo para uso próprio", personal, number(marketValue))
        Text("Atenção: estimativa baseada nos valores informados. Confirme edital, comissão, débitos, restrições e condições do lote antes de ofertar.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
    }
}

@Composable
private fun ResultCard(title: String, result: BidResult, reference: Double) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(money(result.maxBid), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("Custo total estimado: ${money(result.totalCost)}")
            Text("Saldo estimado após custos: ${money(result.profitOrSaving)}")
            val safe = reference > 0 && result.maxBid > 0 && result.profitOrSaving > 0
            Text(if (safe) "Cenário dentro da meta informada" else "Atenção: não há margem positiva com estes dados",
                color = if (safe) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error)
        }
    }
}
