package com.lanceai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.lanceai.app.core.theme.LanceAITheme
import com.lanceai.app.data.local.LanceDatabase
import com.lanceai.app.data.local.VehicleEntity
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = LanceDatabase.get(this)
        setContent {
            LanceAITheme {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            onVehicles = { nav.navigate("vehicles") },
                            onNewVehicle = { nav.navigate("new") },
                            onCalculator = { nav.navigate("calculator") }
                        )
                    }
                    composable("calculator") {
                        CalculatorScreen(onBack = { nav.popBackStack() })
                    }
                    composable("calculator") {
                        CalculatorScreen(onBack = { nav.popBackStack() })
                    }
                    composable("vehicles") {
                        VehicleListScreen(database = database, onBack = { nav.popBackStack() })
                    }
                    composable("new") {
                        NewVehicleScreen(
                            onBack = { nav.popBackStack() },
                            onSave = { make, model, year ->
                                lifecycleScope.launch {
                                    database.vehicleDao().insert(VehicleEntity(make = make, model = model, year = year))
                                    nav.popBackStack()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onVehicles: () -> Unit, onNewVehicle: () -> Unit, onCalculator: () -> Unit) {
    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("LanceAI", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Text("Antes do lance, inteligência.", style = MaterialTheme.typography.titleMedium)
            Text("Análise inteligente para decisões de compra no Palácio dos Leilões.")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNewVehicle, modifier = Modifier.fillMaxWidth()) { Text("Cadastrar veículo") }
            Button(onClick = onVehicles, modifier = Modifier.fillMaxWidth()) { Text("Meus veículos") }
            Button(onClick = onCalculator, modifier = Modifier.fillMaxWidth()) { Text("Calculadora de lance") }
            Button(onClick = onCalculator, modifier = Modifier.fillMaxWidth()) { Text("Calculadora de lance") }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Próximas funções", style = MaterialTheme.typography.titleMedium)
                    Text("Pesquisa de lotes, FIPE, mercado, despesas, lance máximo, fotos e relatórios.")
                }
            }
        }
    }
}

@Composable
private fun NewVehicleScreen(onBack: () -> Unit, onSave: (String, String, Int) -> Unit) {
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("2020") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Novo veículo", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(make, { make = it }, label = { Text("Marca") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(model, { model = it }, label = { Text("Modelo") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, label = { Text("Ano") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = { year.toIntOrNull()?.let { onSave(make.trim(), model.trim(), it) } },
            enabled = make.isNotBlank() && model.isNotBlank() && year.toIntOrNull() != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Salvar veículo") }
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
    }
}

@Composable
private fun VehicleListScreen(database: LanceDatabase, onBack: () -> Unit) {
    val vehicles by database.vehicleDao().observeAll().collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Meus veículos", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = onBack) { Text("Voltar") }
        if (vehicles.isEmpty()) Text("Nenhum veículo cadastrado ainda.")
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vehicles.size) { index ->
                val vehicle = vehicles[index]
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${vehicle.make} ${vehicle.model}", style = MaterialTheme.typography.titleMedium)
                        Text("Ano ${vehicle.year} · ${vehicle.auctionName}")
                    }
                }
            }
        }
    }
}
