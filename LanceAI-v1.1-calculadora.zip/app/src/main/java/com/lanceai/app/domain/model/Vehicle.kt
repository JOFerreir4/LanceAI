package com.lanceai.app.domain.model

data class Vehicle(
    val id: Long = 0,
    val make: String,
    val model: String,
    val year: Int,
    val lotNumber: String = "",
    val auctionName: String = "Palácio dos Leilões"
)
