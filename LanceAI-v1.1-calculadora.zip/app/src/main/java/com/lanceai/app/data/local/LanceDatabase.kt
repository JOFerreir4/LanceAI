package com.lanceai.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [VehicleEntity::class], version = 1, exportSchema = false)
abstract class LanceDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao

    companion object {
        @Volatile private var INSTANCE: LanceDatabase? = null
        fun get(context: Context): LanceDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                LanceDatabase::class.java,
                "lanceai.db"
            ).build().also { INSTANCE = it }
        }
    }
}
