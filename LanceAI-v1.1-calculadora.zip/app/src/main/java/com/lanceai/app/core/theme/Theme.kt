package com.lanceai.app.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val LanceColorScheme = darkColorScheme(
    primary = ElectricCyan,
    secondary = SignalGreen,
    tertiary = AlertAmber,
    background = Midnight,
    surface = DeepBlue,
    onPrimary = Midnight,
    onSecondary = Midnight,
    onBackground = IceWhite,
    onSurface = IceWhite
)

@Composable
fun LanceAITheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LanceColorScheme, content = content)
}
